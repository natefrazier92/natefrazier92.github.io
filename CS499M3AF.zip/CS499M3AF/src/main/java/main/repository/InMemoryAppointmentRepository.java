package main.repository;

import main.Appointment;
import java.util.*;
import java.time.LocalDate;
import main.AppointmentRepository;

public class InMemoryAppointmentRepository implements AppointmentRepository {
    private final Map<String, Appointment> database = new HashMap<>();

    @Override
    public Appointment save(Appointment appointment) {
        database.put(appointment.getAppointmentId(), appointment);
        return appointment;
    }

    @Override
    public Optional<Appointment> findById(String id) {
        return Optional.ofNullable(database.get(id));
    }

    @Override
    public List<Appointment> findAll() {
        return new ArrayList<>(database.values());
    }

    @Override
    public boolean deleteById(String id) {
        return database.remove(id) != null;
    }

   @Override
    public List<Appointment> findByDate(LocalDate date) {
    List<Appointment> matches = new ArrayList<>();

    for (Appointment appointment : database.values()) {
        LocalDate appointmentDate = appointment.getDate()
                .toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();

        if (appointmentDate.equals(date)) {
            matches.add(appointment);
        }
    }

    return matches;
}
}