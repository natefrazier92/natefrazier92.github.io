package main.repository;

import main.AppointmentRepository;
import main.Appointment;

import javax.sql.DataSource;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * SQL implementation of the AppointmentRepository.
 * Uses a DataSource for efficient connection pooling.
 */
public class SqlAppointmentRepository implements AppointmentRepository {

    private final DataSource dataSource;

    // Inject the DataSource (Connection Pool) instead of raw credentials
    public SqlAppointmentRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Appointment save(Appointment appointment) {
        // Note: ON DUPLICATE KEY UPDATE is MySQL specific. 
        // For PostgreSQL, use "ON CONFLICT (appt_id) DO UPDATE SET..."
        String sql = "INSERT INTO appointments (appt_id, appt_date, description) " +
                     "VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE appt_date = ?, description = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, appointment.getAppointmentId());
            // Use java.sql.Date.valueOf for cleaner conversion from LocalDate/Date
            pstmt.setDate(2, new java.sql.Date(appointment.getDate().getTime()));
            pstmt.setString(3, appointment.getDescription());
            pstmt.setDate(4, new java.sql.Date(appointment.getDate().getTime()));
            pstmt.setString(5, appointment.getDescription());
            
            pstmt.executeUpdate();
            return appointment;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving appointment: " + appointment.getAppointmentId(), e);
        }
    }

    @Override
    public Optional<Appointment> findById(String id) {
        String sql = "SELECT appt_id, appt_date, description FROM appointments WHERE appt_id = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRowToAppointment(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding appointment by ID: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Appointment> findAll() {
        String sql = "SELECT appt_id, appt_date, description FROM appointments";
        List<Appointment> appointments = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                appointments.add(mapRowToAppointment(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving all appointments", e);
        }
        return appointments;
    }

    @Override
    public boolean deleteById(String id) {
        String sql = "DELETE FROM appointments WHERE appt_id = ?";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting appointment: " + id, e);
        }
    }

    @Override
    public List<Appointment> findByDate(LocalDate date) {
        String sql = "SELECT appt_id, appt_date, description FROM appointments WHERE appt_date = ?";
        List<Appointment> appointments = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // Convert LocalDate directly to java.sql.Date
            pstmt.setDate(1, Date.valueOf(date));
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    appointments.add(mapRowToAppointment(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding appointments by date: " + date, e);
        }
        return appointments;
    }

    private Appointment mapRowToAppointment(ResultSet rs) throws SQLException {
        return new Appointment(
            rs.getString("appt_id"),
            rs.getDate("appt_date"),
            rs.getString("description")
        );
    }
}