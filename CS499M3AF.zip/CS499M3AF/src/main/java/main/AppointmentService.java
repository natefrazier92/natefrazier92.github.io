package main;

import java.util.List;

public class AppointmentService {
    private final AppointmentRepository repository;

    // We "Inject" the repository via the constructor
    public AppointmentService(AppointmentRepository repository) {
        this.repository = repository;
    }

    public boolean addAppointment(final Appointment newAppt) {
        // The service handles the BUSINESS RULE (no duplicates)
        // The repository handles the DATA RULE (storing it)
        if (repository.findById(newAppt.getAppointmentId()).isPresent()) {
            return false; 
        }
        repository.save(newAppt);
        return true;
    }

    public List<Appointment> getAppointments() {
    return repository.findAll();
    }

    public boolean deleteAppointment(String id) {
        return repository.deleteById(id);
    }
}