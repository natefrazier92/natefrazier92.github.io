
package main;

import java.util.Date;

public class Appointment {
    private String apptId;
    private Date date;
    private String description;

    /**
     * Private default constructor.
     */
    private Appointment() {
    }

    /**
     * Parameterized constructor.
     * Uses validation helpers to ensure object integrity upon creation.
     */
    public Appointment(final String apptId, final Date date, final String description) {
        this();

        // 1. Validate ID
        if (apptId == null || apptId.isBlank()) {
            throw new IllegalArgumentException("apptId cannot be null.");
        } else if (apptId.length() > 10) {
            throw new IllegalArgumentException("apptId cannot be longer than 10 characters.");
        }
        this.apptId = apptId;

        // 2. Validate and set Date
        validateDate(date);
        this.date = date;

        // 3. Validate and set Description
        validateDescription(description);
        this.description = description;
    }

    // --- Validation Helpers ---

    private void validateDate(Date date) {
        if (date == null) {
            throw new IllegalArgumentException("date cannot be null.");
        } else if (date.before(new Date())) {
            throw new IllegalArgumentException("date cannot be in the past.");
        }
    }

    private void validateDescription(String description) {
        if (description == null || description.isBlank()) {
            throw new IllegalArgumentException("description cannot be null.");
        } else if (description.length() > 50) {
            throw new IllegalArgumentException("description cannot be longer than 50 characters.");
        }
    }

    // --- Getters and Setters ---

    public String getAppointmentId() {
        return apptId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        validateDate(date); // Reuse the helper!
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        validateDescription(description); // Reuse the helper!
        this.description = description;
    }

}