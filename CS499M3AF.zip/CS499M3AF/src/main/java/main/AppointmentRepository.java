package main;


import java.util.List;
import java.util.Optional;
import java.time.LocalDate;

/**
 * Interface for Appointment data access.
 * This allows the AppointmentService to remain agnostic of the storage mechanism
 * (whether it is an In-Memory List, a SQL Database, or a File).
 */
public interface AppointmentRepository {

    /**
     * Persists an appointment.
     * @param appointment The appointment to save.
     * @return The saved appointment.
     */
    Appointment save(Appointment appointment);

    /**
     * Finds an appointment by its unique ID.
     * Using Optional prevents NullPointerExceptions in the Service layer.
     * @param id The appointment ID.
     * @return An Optional containing the appointment if found.
     */
    Optional<Appointment> findById(String id);

    /**
     * Retrieves all appointments.
     * @return A list of all appointments.
     */
    List<Appointment> findAll();

    /**
     * Removes an appointment from storage.
     * @param id The ID of the appointment to delete.
     * @return true if an appointment was removed, false otherwise.
     */
    boolean deleteById(String id);

    /**
     * Finds appointments scheduled for a specific day.
     * @param date The date to search for.
     * @return A list of appointments on that date.
     */
    List<Appointment> findByDate(LocalDate date);
}