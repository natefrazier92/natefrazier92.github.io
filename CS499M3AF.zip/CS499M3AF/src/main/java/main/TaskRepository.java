package main;

import java.util.Optional;

public interface TaskRepository {
    void save(Task task);
    Optional<Task> findById(String id);
    boolean deleteById(String id);
    int count();
}