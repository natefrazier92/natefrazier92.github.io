package test;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import main.Task;
import main.TaskRepository;


class InMemoryTaskRepository implements TaskRepository {
    private final Map<String, Task> tasks = new HashMap<>();

    @Override
    public void save(Task task) {
        tasks.put(task.getUniqueID(), task);
    }

    @Override
    public Optional<Task> findById(String id) {
        return Optional.ofNullable(tasks.get(id));
    }

    @Override
    public boolean deleteById(String id) {
        return tasks.remove(id) != null;
    }

    @Override
    public int count() {
        return tasks.size();
    }
}