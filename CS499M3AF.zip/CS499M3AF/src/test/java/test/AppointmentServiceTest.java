package test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.Date;
import java.time.LocalDate;
import java.time.ZoneId;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Appointment;
import main.AppointmentService;
import main.repository.InMemoryAppointmentRepository;

class AppointmentServiceTest {
    private AppointmentService testApptService;
    private Date testApptDate;
    
    @BeforeEach
    @SuppressWarnings("unused")
    void setUp() {
    testApptDate = Date.from(
        LocalDate.now()
            .plusDays(1)
            .atStartOfDay(ZoneId.systemDefault())
            .toInstant()
    );

        // Create the repository first, then inject it into the service
        InMemoryAppointmentRepository fakeRepo = new InMemoryAppointmentRepository();
        testApptService = new AppointmentService(fakeRepo);
        
        // Pre-loading the service
        testApptService.addAppointment(new Appointment("1", testApptDate, "description1"));
        testApptService.addAppointment(new Appointment("2", testApptDate, "description2"));
    }

    
    @Test
    @DisplayName("Should successfully add a unique appointment")
    void testAddAppointment() {
        assertAll(
            () -> assertTrue(testApptService.addAppointment(new Appointment("3", testApptDate, "description3")), "Appointment should be added successfully"),
            () -> assertEquals(3, testApptService.getAppointments().size(), "List size should be 3 after adding")
        );
    }
    
    @Test
    @DisplayName("Should reject an appointment with an ID that already exists")
    void testAddAppointmentThatAlreadyExists() {
        // We know ID "2" was added in setUp()
        assertFalse(testApptService.addAppointment(new Appointment("2", testApptDate, "new description")), 
            "Should return false when adding a duplicate ID");
        assertEquals(2, testApptService.getAppointments().size(), "Size should remain 2");
    }

    @Test
    @DisplayName("Should successfully delete an existing appointment")
    void testDeleteAppointmentWithValidId() {
        assertAll(
            () -> assertTrue(testApptService.deleteAppointment("2"), "Delete should return true for existing ID"),
            () -> assertEquals(1, testApptService.getAppointments().size(), "Size should be 1 after deletion")
        );
    }
    
    @Test
    @DisplayName("Should return false when attempting to delete a non-existent ID")
    void testDeleteAppointmentWithInvalidId() {
        assertAll(
            () -> assertFalse(testApptService.deleteAppointment("5"), "Delete should return false for non-existent ID"),
            () -> assertEquals(2, testApptService.getAppointments().size(), "Size should remain 2")
        );
    }
}