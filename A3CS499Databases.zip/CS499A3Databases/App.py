import os
from threading import Lock
from urllib.parse import quote_plus

from dotenv import load_dotenv
from pymongo import MongoClient
from bson.objectid import ObjectId

load_dotenv()


class AnimalShelter:
    """Shelter data access using one shared MongoDB client per process."""

    _client = None
    _lock = Lock()

    def __init__(self):
        username = os.getenv("MONGO_USERNAME")
        password = os.getenv("MONGO_PASSWORD")
        host = os.getenv("MONGO_HOST", "localhost")
        port = int(os.getenv("MONGO_PORT", "27017"))
        auth_source = os.getenv("MONGO_AUTH_SOURCE") or "aac"

        if not username or not password:
            raise RuntimeError(
                "Set MONGO_USERNAME and MONGO_PASSWORD in your .env file."
            )

        with self._lock:
            if self.__class__._client is None:
                uri = (
                    f"mongodb://{quote_plus(username)}:{quote_plus(password)}"
                    f"@{host}:{port}/?authSource={quote_plus(auth_source)}"
                )
                self.__class__._client = MongoClient(
                    uri,
                    maxPoolSize=50,
                    serverSelectionTimeoutMS=5000,
                )

        self.client = self.__class__._client
        database_name = os.getenv("MONGO_DATABASE", "AnimalShelter")
        collection_name = os.getenv("MONGO_COLLECTION", "Animals")
        self.database = self.client[database_name]
        self.collection = self.database[collection_name]

        self.records_updated = 0
        self.records_matched = 0
        self.records_deleted = 0

    def createRecord(self, data):
        if not data:
            raise ValueError("No document to save.")
        return self.collection.insert_one(data).acknowledged

    def getRecordId(self, post_id):
        return self.collection.find_one({"_id": ObjectId(post_id)})

    def getRecordCriteria(self, criteria=None):
        return self.collection.find(criteria or {}, {"_id": 0})

    def updateRecord(self, query, new_value):
        if not query or not new_value:
            raise ValueError("Search criteria and update value are required.")
        result = self.collection.update_many(query, {"$set": new_value})
        self.records_updated = result.modified_count
        self.records_matched = result.matched_count
        return result.modified_count > 0

    def deleteRecord(self, query):
        if not query:
            raise ValueError("Search criteria are required.")
        result = self.collection.delete_many(query)
        self.records_deleted = result.deleted_count
        return result.deleted_count > 0