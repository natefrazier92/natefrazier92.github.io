

from datetime import datetime as DateTime
import re

import dash
import dash_bootstrap_components as dbc
import dash_leaflet as dl
import numpy as np
import pandas as pd
import plotly.express as px
from dash import Input, Output, State, dcc, html, dash_table
from jupyter_dash import JupyterDash
from pydantic import BaseModel, ConfigDict, ValidationError
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from App import AnimalShelter


# Validate MongoDB documents before converting them to a DataFrame.
class AnimalRecord(BaseModel):
    model_config = ConfigDict(extra="ignore", coerce_numbers_to_str=True)

    breed: str = "Unknown"
    name: str = "Unknown"
    sex_upon_outcome: str = "Unknown"
    outcome_type: str = "Unknown"
    age_upon_outcome_in_weeks: float | None = None
    location_lat: float | None = None
    location_long: float | None = None
    datetime: str | None = None
    date_of_birth: DateTime | str | None = None


shelter = AnimalShelter()


def load_records(criteria=None):
    valid_records = []
    for document in shelter.getRecordCriteria(criteria):
        try:
            valid_records.append(AnimalRecord.model_validate(document).model_dump())
        except ValidationError:
            # Skip malformed documents rather than breaking the dashboard.
            continue
    return pd.DataFrame(valid_records)


def build_model(data):
    """Train a small demonstration classifier when both target classes exist."""
    if data.empty or "outcome_type" not in data:
        return None

    frame = data.copy()
    frame["age_upon_outcome_in_weeks"] = pd.to_numeric(
        frame["age_upon_outcome_in_weeks"], errors="coerce"
    )

    outcome = frame["outcome_type"].fillna("").str.lower()
    frame["target"] = np.select(
        [
            outcome.str.contains(r"adopt", regex=True),
            outcome.str.contains(r"return to shelter|return", regex=True),
        ],
        ["Successful Adoption", "Return to Shelter"],
        default="",
    )
    frame = frame[frame["target"] != ""]

    if frame["target"].nunique() < 2 or len(frame) < 10:
        return None

    features = ["age_upon_outcome_in_weeks", "breed", "sex_upon_outcome"]
    preprocessor = ColumnTransformer(
        [
            (
                "age",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="median")),
                        ("scale", StandardScaler()),
                    ]
                ),
                ["age_upon_outcome_in_weeks"],
            ),
            (
                "category",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("encode", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                ["breed", "sex_upon_outcome"],
            ),
        ]
    )
    model = Pipeline(
        [
            ("preprocessor", preprocessor),
            ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced")),
        ]
    )
    model.fit(frame[features], frame["target"])
    return model


initial_df = load_records()
model = build_model(initial_df)

app = JupyterDash(
    "Animal Shelter Insights",
    external_stylesheets=[dbc.themes.FLATLY],
    suppress_callback_exceptions=True,
)

breed_options = sorted(
    initial_df["breed"].dropna().astype(str).unique().tolist()
) if not initial_df.empty else []

age_values = pd.to_numeric(
    initial_df.get("age_upon_outcome_in_weeks", pd.Series(dtype=float)),
    errors="coerce",
).dropna()

age_min = float(age_values.min()) if not age_values.empty else 0
age_max = float(age_values.max()) if not age_values.empty else 300
if age_min == age_max:
    age_max = age_min + 1

app.layout = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(
                    html.Div(
                        [
                            html.H1("Animal Shelter Insights", className="mb-1"),
                            html.P(
                                "Explore shelter outcomes, intake trends, and locations.",
                                className="text-muted",
                            ),
                        ],
                        className="py-4",
                    ),
                    width=12,
                )
            ]
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Label("Rescue profile"),
                                dcc.Dropdown(
                                    id="filter-type",
                                    options=[
                                        {"label": "All animals", "value": "All"},
                                        {"label": "Water rescue", "value": "Water"},
                                        {"label": "Mountain / wilderness", "value": "Mountain"},
                                        {"label": "Disaster / tracking", "value": "Disaster"},
                                    ],
                                    value="All",
                                    clearable=False,
                                ),
                                html.Label("Breeds", className="mt-3"),
                                dcc.Dropdown(
                                    id="breed-filter",
                                    options=[{"label": b, "value": b} for b in breed_options],
                                    multi=True,
                                    placeholder="All breeds",
                                ),
                                html.Label("Age range (weeks)", className="mt-3"),
                                dcc.RangeSlider(
                                    id="age-filter",
                                    min=age_min,
                                    max=age_max,
                                    step=1,
                                    value=[age_min, age_max],
                                    marks=None,
                                    tooltip={"placement": "bottom", "always_visible": True},
                                ),
                            ]
                        ),
                        className="shadow-sm",
                    ),
                    width=12,
                    className="mb-3",
                )
            ]
        ),
        dbc.Row(
            [
                dbc.Col(
                    dash_table.DataTable(
                        id="datatable-id",
                        columns=[
                            {"name": col, "id": col}
                            for col in initial_df.columns
                        ],
                        data=initial_df.to_dict("records"),
                        page_size=10,
                        page_action="native",
                        sort_action="native",
                        filter_action="native",
                        row_selectable="single",
                        selected_rows=[],
                        style_table={"overflowX": "auto"},
                        style_cell={
                            "textAlign": "left",
                            "padding": "8px",
                            "minWidth": "100px",
                            "maxWidth": "240px",
                            "whiteSpace": "normal",
                        },
                        style_header={"fontWeight": "bold"},
                    ),
                    width=12,
                )
            ],
            className="mb-3",
        ),
        dbc.Row(
            [
                dbc.Col(dcc.Graph(id="intake-chart"), xs=12, lg=6),
                dbc.Col(dcc.Graph(id="outcome-chart"), xs=12, lg=6),
            ]
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.H4("Animal locations"),
                        dcc.RadioItems(
                            id="map-mode",
                            options=[
                                {"label": "Clustered markers", "value": "markers"},
                                {"label": "Individual points", "value": "points"},
                            ],
                            value="markers",
                            inline=True,
                            className="mb-2",
                        ),
                        html.Div(id="map-id"),
                    ],
                    xs=12,
                    lg=7,
                    className="mb-4",
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.H4("Outcome prediction"),
                                html.P(
                                    "Estimated probabilities from a model trained on "
                                    "available shelter records.",
                                    className="text-muted",
                                ),
                                dbc.Label("Age (weeks)"),
                                dbc.Input(
                                    id="predict-age",
                                    type="number",
                                    min=0,
                                    value=52,
                                ),
                                dbc.Label("Breed", className="mt-2"),
                                dcc.Dropdown(
                                    id="predict-breed",
                                    options=[{"label": b, "value": b} for b in breed_options],
                                    value=breed_options[0] if breed_options else None,
                                    placeholder="Select a breed",
                                ),
                                dbc.Label("Sex", className="mt-2"),
                                dcc.Dropdown(
                                    id="predict-sex",
                                    options=[
                                        {"label": s, "value": s}
                                        for s in sorted(
                                            initial_df.get(
                                                "sex_upon_outcome", pd.Series(dtype=str)
                                            ).dropna().astype(str).unique()
                                        )
                                    ],
                                    value="Intact Male",
                                ),
                                dbc.Button(
                                    "Predict outcome",
                                    id="predict-button",
                                    color="primary",
                                    className="mt-3",
                                ),
                                html.Div(id="prediction-result", className="mt-3"),
                            ]
                        ),
                        className="shadow-sm",
                    ),
                    xs=12,
                    lg=5,
                    className="mb-4",
                ),
            ]
        ),
    ],
    fluid=True,
    className="px-3 px-md-4",
)


def rescue_query(filter_type):
    profiles = {
        "Water": {
            "$or": [
                {"breed": {"$regex": pattern, "$options": "i"}}
                for pattern in ["lab", "chesa", "newf"]
            ],
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        },
        "Mountain": {
            "$or": [
                {"breed": {"$regex": pattern, "$options": "i"}}
                for pattern in ["german", "mala", "old english", "husk", "rott"]
            ],
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        },
        "Disaster": {
            "$or": [
                {"breed": {"$regex": pattern, "$options": "i"}}
                for pattern in ["german", "golden", "blood", "dober", "rott"]
            ],
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
        },
    }
    return profiles.get(filter_type)


@app.callback(
    Output("datatable-id", "data"),
    Output("datatable-id", "columns"),
    Input("filter-type", "value"),
    Input("breed-filter", "value"),
    Input("age-filter", "value"),
)
def update_table(filter_type, breeds, age_range):
    data = load_records(rescue_query(filter_type))
    if data.empty:
        return [], []

    if breeds:
        data = data[data["breed"].isin(breeds)]

    if age_range:
        ages = pd.to_numeric(data["age_upon_outcome_in_weeks"], errors="coerce")
        data = data[ages.between(age_range[0], age_range[1])]

    columns = [{"name": col, "id": col} for col in data.columns]
    return data.to_dict("records"), columns


@app.callback(
    Output("intake-chart", "figure"),
    Output("outcome-chart", "figure"),
    Input("datatable-id", "derived_virtual_data"),
)
def update_charts(records):
    data = pd.DataFrame(records or [])

    if data.empty:
        empty = px.scatter(title="No records match these filters.")
        return empty, empty

    # Use the available date field; invalid/missing values are excluded.
    date_column = next(
        (c for c in ("datetime", "date_of_birth") if c in data.columns), None
    )
    if date_column:
        dates = pd.to_datetime(data[date_column], errors="coerce")
        monthly = (
            dates.dropna()
            .dt.to_period("M")
            .value_counts()
            .sort_index()
            .rename_axis("month")
            .reset_index(name="intakes")
        )
        monthly["month"] = monthly["month"].astype(str)
        intake_fig = px.line(
            monthly, x="month", y="intakes", markers=True,
            title="Animal intakes per month",
        )
    else:
        intake_fig = px.scatter(title="No usable intake date field in these records.")

    if {"breed", "outcome_type"}.issubset(data.columns):
        outcomes = data.copy()
        outcomes["breed"] = outcomes["breed"].fillna("Unknown")
        outcomes["outcome_type"] = outcomes["outcome_type"].fillna("Unknown")
        top_breeds = outcomes["breed"].value_counts().head(12).index
        outcomes = outcomes[outcomes["breed"].isin(top_breeds)]
        outcome_fig = px.histogram(
            outcomes,
            x="breed",
            color="outcome_type",
            barmode="stack",
            title="Breed and outcome",
            labels={"breed": "Breed", "outcome_type": "Outcome"},
        )
        outcome_fig.update_layout(xaxis_tickangle=-35)
    else:
        outcome_fig = px.scatter(title="Outcome fields are unavailable.")

    return intake_fig, outcome_fig


@app.callback(
    Output("map-id", "children"),
    Input("datatable-id", "derived_virtual_data"),
    Input("datatable-id", "derived_virtual_selected_rows"),
    Input("map-mode", "value"),
)
def update_map(records, selected_rows, map_mode):
    data = pd.DataFrame(records or [])
    if data.empty or not {"location_lat", "location_long"}.issubset(data.columns):
        return dbc.Alert("No location data is available for these records.", color="info")

    data["location_lat"] = pd.to_numeric(data["location_lat"], errors="coerce")
    data["location_long"] = pd.to_numeric(data["location_long"], errors="coerce")
    data = data.dropna(subset=["location_lat", "location_long"])

    if data.empty:
        return dbc.Alert("No mappable locations match these filters.", color="info")

    center = [float(data["location_lat"].mean()), float(data["location_long"].mean())]

    features = [
        {
            "type": "Feature",
            "properties": {"name": str(name), "breed": str(breed)},
            "geometry": {
                "type": "Point",
                "coordinates": [float(longitude), float(latitude)],
            },
        }
        for longitude, latitude, name, breed in zip(
            data["location_long"],
            data["location_lat"],
            data["name"],
            data["breed"],
        )
    ]
    layer = dl.GeoJSON(
        data={"type": "FeatureCollection", "features": features},
        cluster=map_mode == "markers",
        zoomToBoundsOnClick=True,
    )

    return dl.Map(
        center=center,
        zoom=9,
        style={"width": "100%", "height": "480px"},
        children=[dl.TileLayer(), layer],
    )


@app.callback(
    Output("prediction-result", "children"),
    Input("predict-button", "n_clicks"),
    State("predict-age", "value"),
    State("predict-breed", "value"),
    State("predict-sex", "value"),
    prevent_initial_call=True,
)
def predict_outcome(_, age, breed, sex):
    if model is None:
        return dbc.Alert(
            "There is not enough labeled outcome data to train a prediction model.",
            color="warning",
        )
    if age is None or not breed or not sex:
        return dbc.Alert("Enter an age, breed, and sex.", color="warning")

    sample = pd.DataFrame(
        [{
            "age_upon_outcome_in_weeks": float(age),
            "breed": breed,
            "sex_upon_outcome": sex,
        }]
    )
    probabilities = model.predict_proba(sample)[0]
    classes = model.named_steps["classifier"].classes_

    results = {
        str(label): float(probability)
        for label, probability in zip(classes, probabilities)
    }
    adoption = results.get("Successful Adoption", 0.0)
    return_shelter = results.get("Return to Shelter", 0.0)

    return dbc.Alert(
        [
            html.Div(f"Successful Adoption: {adoption:.1%}"),
            html.Div(f"Return to Shelter: {return_shelter:.1%}"),
            html.Small(
                "Estimates reflect the training data and are not a guarantee.",
                className="d-block mt-2",
            ),
        ],
        color="success",
    )


if __name__ == "__main__":
    app.run(debug=False)